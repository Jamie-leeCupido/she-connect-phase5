import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-findmentor',
  imports: [RouterModule],
  templateUrl: './findmentor.html',
  styleUrl: './findmentor.css'
})
export class FindmentorComponent {

}
